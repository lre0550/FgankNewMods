/* 
BSL Shaders v8 Series by Capt Tatsu 
https://capttatsu.com 
*/ 

#version 120 

#define OVERWORLD
#define FSH

#include "/program/shadow.glsl"
